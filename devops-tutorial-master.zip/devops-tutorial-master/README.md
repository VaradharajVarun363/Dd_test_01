<<<<<<< HEAD
# Hello Node
This is a very basic Hello World application written with Node.

It includes a `Dockerfile` for building a Docker image with the application, and a `Jenkinsfile` that defines a build pipeline for it.

https://getintodevops.com
=======
# devops-tutorial
>>>>>>> ce3c95b92d0a737f7f47667c31aafe18343361c6
